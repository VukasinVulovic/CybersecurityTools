const cryptofile = require('./cryptofile');

(async() => {
    cryptofile.decryptItem(process.argv[2], process.argv[3]);
    console.log('Decrypted succesuflly;');
})();