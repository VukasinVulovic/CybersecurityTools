const { spawn } = require('child_process');
const os = require('os');
const fs = require('fs-extra');
const Path = require('path');
const crypto = require('crypto');
const TEMP = os.tmpdir();

module.exports = {
    generateKey,
    encryptItem,
    decryptItem
}

function generateKey() {
    let key = '';

    for(let i = 0; i < 48; i++)
        key += '1234567890qwertyuiopasdfghjklzxcvbnm'[Math.floor(Math.random() * 36)];
    
    return key;
}

async function decryptItem(file_path, key) {
    return new Promise(async(resolve, reject) => {
        const cipher = crypto.createDecipheriv('aes-256-cbc', key.slice(16), key.slice(0, 16));

        const i = fs.createReadStream(file_path);
        const o = fs.createWriteStream(file_path.slice(0, file_path.length-5));

        i.pipe(cipher);
        cipher.pipe(o);
        o.on('close', () => {
            fs.removeSync(file_path);
            resolve(file_path);
        });
    });
}

async function encryptItem(item_path, key) {
    return new Promise(async(resolve, reject) => {
        let ifile = item_path;
        let ofile = item_path;
        
        if(fs.statSync(ifile).isDirectory()) {
            const file = Path.basename(item_path);
            const t_file = Path.join(TEMP, '\\node-encrypter\\', file);
            
            await zipArchive(ifile, t_file);
            fs.removeSync(ifile);
            
            ifile = t_file + '.7z';
            ofile = Path.join(Path.parse(item_path).dir, file + '.7z');
        }

        const cipher = crypto.createCipheriv('aes-256-cbc', key.slice(16), key.slice(0, 16));

        const i = fs.createReadStream(ifile);
        const o = fs.createWriteStream(ofile + '.lock');

        i.pipe(cipher);
        cipher.pipe(o);

        o.on('close', () => {
            fs.removeSync(ifile);
            resolve(ofile + '.lock');
        });
    });
}

async function zipArchive(input, output) {
    return new Promise((resolve, reject) => {
        const s = spawn(__dirname + '\\bin\\7zip.exe', ['a', output, input]);
        let data = '';
        
        s.stdout
        .on('data', chunk => data += chunk.toString())
        .on('end', () => {
            if(data.includes('Everything is Ok'))
                return resolve(data);

            reject(data);
        });
    });
}