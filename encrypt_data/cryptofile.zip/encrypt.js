const cryptofile = require('./cryptofile');

(async() => {
    const key = cryptofile.generateKey();
    cryptofile.encryptItem(process.argv[2], key);
    console.log('Decryption key is "' + key + '";');
})();