const nettools = require('./');

(async() => {
    console.log(await nettools.scanPorts('192.168.1.29'))
})().catch(console.error);