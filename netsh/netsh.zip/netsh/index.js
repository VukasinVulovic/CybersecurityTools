const { exec, spawn } = require('child_process');
const http = require('http');

async function ping(domain, timeout, n, size) {
    return new Promise((resolve, reject) => {
        const s = spawn('ping', [domain, '-n', n, '-l', size, '-w', timeout], {});
        let err = '', data = '';

        s.on('error', reject);
        
        s.stderr
        .on('data', chunk => err += chunk.toString())
        .on('end', () => {
            if(err.length > 0)    
                reject(err);
        });

        s.stdout
        .on('data', chunk => data += chunk.toString())
        .on('end', () => {
            if(data.includes('host unreachable') || data.includes('timed out'))
                resolve(false);

            let avg = data.slice(data.indexOf('Average =')+10, data.lastIndexOf('s'));
            avg = parseInt(avg);
            resolve(avg === NaN ? false : avg);
        });
    });
}

async function pingPort(host, port, timeout) {
    return new Promise((resolve, reject) => {
        const t = (new Date()).getTime();
        const req = http
        .request({
            host,
            port,
            timeout
        }, res => {
            req.destroy();
            resolve((new Date()).getTime()-t);
        });

        const errCb = e => {
            if((e || '').toString() === 'Error: Parse Error: Expected HTTP/') {
                req.destroy();
                return resolve((new Date()).getTime()-t);
            }

            req.destroy();
            resolve(false);
        }

        req
        .on('error', errCb)
        .on('socket', () => setTimeout(errCb, timeout));

        req.write('');
        req.end();
    });
}

module.exports = {
    netsh: {
        wifi: {
            getInterfaces: async function() {
                return new Promise((resolve, reject) => {
                    const s = exec('netsh wlan show interfaces');
                    let data = '', err = '';
            
                    s.on('error', reject);
            
                    s.stderr
                    .on('data', chunk => err += chunk.toString())
                    .on('end', () => {
                        if(err.length > 0)
                            reject(err);
                    });
            
                    s.stdout
                    .on('data', chunk => data += chunk.toString())
                    .on('end', () => {
                        const interfaces = [];
                        let flag = 0;
            
                        for(const line of data.replace(/\r/g, '').split('\n')) {
                            let [key, value] = line.trim().split(': ');
                            [key, value] = [key.trim(), (value || '').trim()];
            
                            if(key === 'Name')
                                flag++;
            
                            if(!interfaces[flag])
                                interfaces[flag] = {};
            
                            if(value && value.length > 0)
                                interfaces[flag] = Object.assign(interfaces[flag], JSON.parse(`{"${key}": "${value}"}`));
                        }
            
                        resolve(interfaces.filter(v => Object.keys(v).length > 0));
                    });
                });
            },
            getVisibleSSIDS: async function(interface) {
                return new Promise((resolve, reject) => {
                    const s = exec('netsh wlan show networks interface="' + interface + '"');
                    let data = '', err = '';
            
                    s.on('error', reject);
            
                    s.stderr
                    .on('data', chunk => err += chunk.toString())
                    .on('end', () => {
                        if(err.length > 0)
                            reject(err);
                    });
            
                    s.stdout
                    .on('data', chunk => data += chunk.toString())
                    .on('end', () => {
                        const ssids = [];
                        let flag = 0;
            
                        for(const line of data.replace(/\r/g, '').split('\n')) {
                            let [key, value] = line.trim().split(': ');
                            [key, value] = [key.trim(), (value || '').trim()];
            
                            if(key.includes('SSID'))
                                flag++;
            
                            if(!ssids[flag])
                            ssids[flag] = {};
            
                            if(value && value.length > 0) {
                                const k = {}
                                k[key] = value;
                                ssids[flag] = Object.assign(ssids[flag], k);
                            }
                        }
            
                        resolve(ssids.filter(v => Object.keys(v).length > 2));
                    });
                });
            },
            getSavedSSIDS: async function(interface) {
                return new Promise((resolve, reject) => {
                    const s = spawn('netsh', ['wlan', 'show', 'profiles', (interface ? ('interface="' + interface + '"') : '')]);
                    let data = '', err = '';
            
                    s.on('error', reject);
            
                    s.stderr
                    .on('data', chunk => err += chunk.toString())
                    .on('end', () => {
                        if(err.length > 0)
                            reject(err);
                    });
            
                    s.stdout
                        .on('data', chunk => data += chunk.toString())
                        .on('end', () => {
                            const ssids = [];
            
                            for(const line of data.replace(/\r/g, '').split('\n')) {
                                let [key, value] = line.trim().split(': ');
                                [key, value] = [key.trim(), (value || '').trim()];
            
                                if(value && value.length > 0)
                                    ssids.push(value);                 
                            }
            
                            resolve(ssids.filter(v => Object.keys(v).length > 0));
                        });
                });
            },
            getSSIDKey: async function(ssid) {
                return new Promise((resolve, reject) => {
                    const s = exec('netsh wlan show profile "' + ssid + '" key=clear');
                    let data = '', err = '';
            
                    s.on('error', reject);
            
                    s.stderr
                    .on('data', chunk => err += chunk.toString())
                    .on('end', () => {
                        if(err.length > 0)
                            reject(err);
                    });
            
                    s.stdout
                    .on('data', chunk => data += chunk.toString())
                    .on('end', () => {
                        for(const line of data.replace(/\r/g, '').split('\n')) {
                            let [key, value] = line.trim().split(': ');
                            [key, value] = [key.trim(), (value || '').trim()];
            
                            if(key === 'Key Content')
                                return resolve(value);
                        }
            
                        resolve('');
                    });
                });
            },
            getAllInfo: async function() {
                const interfaces = await getInterfaces();
                let saved_ssids = [];
                let visible_ssids = [];
                let keys = {}
                
                for(const interface of interfaces) {
                    const s = await getSavedSSIDS(interface['Name']);
                    const v = await getVisibleSSIDS(interface['Name']);
                    saved_ssids = Object.assign(saved_ssids, s);
                    visible_ssids = Object.assign(visible_ssids, v);
                }
            
                for(const s of saved_ssids) {
                    const key = await getSSIDKey(s);
                    const k = {}
                    k[s] = key;
                    keys = Object.assign(keys, k);
                }
            
                return {
                    interfaces,
                    visible_ssids,
                    saved_ssids,
                    keys
                }
            }
        }
    },
    ipconfig: async function() {
        return new Promise((resolve, reject) => {
            const s = spawn('ipconfig', ['/all'], {});
            let data = '', err = '';
    
            s.on('error', reject);
    
            s.stderr
            .on('data', chunk => err += chunk.toString())
            .on('end', () => {
                if(err.length > 0)
                    reject(err);
            });
    
            
            s.stdout
            .on('data', chunk => data += chunk.toString())
            .on('end', () => {
                const adapters = [];
                let flag = 0;
                let adapter = '';

                for(const line of data.replace(/\r/g, '').split('\n')) {                    
                    let [key, value] = line.trim().split(': ');
                    [key, value] = [key.trim(), (value || '').trim()];

                    if(!adapters[flag])
                        adapters[flag] = {}

                    if(line.includes(' adapter ')) {
                        adapter = line.slice(0, line.length-1);
                        flag++;
                    }

                    if(value.length < 1)
                        continue;

                    const k = {}
                    if(!k['Name']) 
                        k['Name'] = adapter;

                    k[key.replace(/\./g, '').trim()] = value;

                    adapters[flag] = Object.assign(adapters[flag], k);
                }

                const current = (() => {
                    for(const a of adapters) {
                        if(a['IPv4 Address']) {
                            if(a['Media State'] !== 'Media disconnected') {
                                return Object.assign(a, {
                                    'IPv4 Address': a['IPv4 Address'].replace('(Preferred)', '')
                                });
                            }
                        }
                    }

                    return {}
                })();

                adapters.shift();
                resolve({ 
                    current,
                    adapters
                });
            });
        });
    },
    arp: async function() {
        return new Promise((resolve, reject) => {
            const s = spawn('arp', ['-a', '-v'], {});
            let data = '', err = '';
    
            s.on('error', reject);
    
            s.stderr
            .on('data', chunk => err += chunk.toString())
            .on('end', () => {
                if(err.length > 0)
                    reject(err);
            });
    
            
            s.stdout
            .on('data', chunk => data += chunk.toString())
            .on('end', () => {
                const tables = [];
                let interface = '';

                for(const line of data.replace(/\r/g, '').split('\n')) {
                    if(line.includes('Interface')) {
                        interface = line;
                    } else {
                        const parts = line
                        .trim()
                        .split('    ')
                        .filter(v => v.length > 0);

                        if(parts.length < 1 || parts[0] === 'Internet Address')
                            continue;

                        let [ ip, mac, type ] = parts;

                        if(!type)
                            [type, mac] = [mac, ''];

                        type = type.trim();

                        interface = interface.replace('Interface: ', '');

                        if(!tables[interface])
                            tables[interface] = []

                        tables[interface].push({
                            ip, 
                            mac: mac.trim(), 
                            type
                        });
                    }
                }

                resolve(tables);
            });
        });
    },
    getMacFromIp: async function(ip) {
        return new Promise((resolve, reject) => {
            const s = exec('ping ' + ip + ' -n 1 -w 10 > nul && arp -a ' + ip, {}); //-n 1 -w 10 > nul && arp -a | findstr /C:
            let data = '', err = '';
    
            s.on('error', reject);
    
            s.stderr
            .on('data', chunk => err += chunk.toString())
            .on('end', () => {
                if(err.length > 0)
                    reject(err);
            });
    
            
            s.stdout
            .on('data', chunk => data += chunk.toString())
            .on('end', () => {
                const mac = data
                .split('    ')[4];

                if(data.includes('No ARP Entries Found.') || (mac || '').length < 10)
                    return reject('Could not find MAC address.');

                resolve((mac || '').trim());
            });
        });
    },
    ping,
    pingPort,
    scanPorts: async function(host, from, to) {
        const dumbScan = async() => {
            const ports = [];
            for(let i = from; i <= to; i++) {
                const res = await pingPort(host, i, 200);
                
                if(res !== false)
                    ports.push(i);
            }

            return ports;
        }

        const smartScan = async() => {
            const ports = [];
            const services = [
                7, 20, 21, 22, 23, 25, 37, 42, 43, 52, 53, 80, 108, 111, 115, 123, 135, 137, 138, 139, 177, 194, 311, 434, 443, 444, 445, 514, 992, 993, 3000, 5500, 8000, 8080
            ];

            for(const s of services) {
                const res = await pingPort(host, s, 200);

                if(res !== false)
                    ports.push(s);
            }

            return ports;
        }
        
        if(typeof from === 'number' && typeof to === 'number')
            return dumbScan();
        else
            return smartScan();
    },
    scanIpRange: async function(from, to, timeout=1) {
        return new Promise(async resolve => {
            from = from.split('.');
            to = to.split('.');

            const ips = [];

            for(let a = parseInt(from[0]); a < parseInt(to[0])+1; a++) {
                for(let b = parseInt(from[1]); b < parseInt(to[1])+1; b++) {
                    for(let c = parseInt(from[2]); c < parseInt(to[2])+1; c++) {
                        for(let d = parseInt(from[3]); d < parseInt(to[3])+1; d++) {
                            const s = `${a}.${b}.${c}.${d}`;
                            const t = await ping(s, timeout, 1, 1);
                            
                            if(t !== false) 
                                ips.push(s);
                        }
                    }
                }
            }
            
            resolve(ips);
        });
    }
}