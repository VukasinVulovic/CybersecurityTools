const WebSocket = require('ws');
const url = require('url');
let Sockets = {}
let Viewers = {}

module.exports = (Port, connection_cb=(a, b) => {}) => {   
    return new Promise((resolve, reject) => {
        try {
            const Ws = new WebSocket.Server({
                port: Port
            });
            
            Ws.on('connection', (socket, req) => {
                if(url.parse(req.url, true).query['ip']) { //sender
                    const ip = url.parse(req.url, true).query['ip'];
                    Sockets[ip] = socket;
                    socket.ip = ip;
                    socket.on('close', () => delete Sockets[socket]);
                    
                    socket.on('message', message => {
                        if(Viewers[ip])
                            Viewers[ip].send(message);
                    });
                    
                    connection_cb(ip, socket);
                } else if(url.parse(req.url, true).query['control_ip']) { //viewer
                    const control_ip = url.parse(req.url, true).query['control_ip'];
                    Viewers[control_ip] = socket;
                    Viewers.control_ip = control_ip;
                    if(Viewers[control_ip] && Sockets[control_ip])
                        Sockets[control_ip].send('start$,$start');
                    
                    socket.on('close', () => {
                        if(Sockets[control_ip])
                            Sockets[control_ip].send('stop$,$stop');
                        delete Sockets[socket];
                    });

                    socket.on('message', message => {
                        if(Sockets[control_ip])
                            Sockets[control_ip].send(message);
                    });

                    connection_cb(control_ip, socket);      
                }
            });
            resolve(Ws);
        } catch(e) {
            //reject(e);
        }
    });
}

// ws.on('connection', (sokcet, req) => {
//     const query = url.parse(req.url, true).query;
//     if(query['ip']) {
//         client = sokcet;
//         sokcet.on('close', () => client = null);    
//         sokcet.on('message', message => {
//             if(controller)
//                 controller.send(message);
//         });
//     } else if(query['contol_ip']) {
//         controller = sokcet;
//         sokcet.on('close', () => controller = null);
//         sokcet.on('message', message => {
//             if(client)
//                 client.send(message);
//         });
//     }
// });