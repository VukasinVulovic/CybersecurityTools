let ws = '';
const screen = document.querySelector('.screen');
const pointer = {
    pointer: (() => {
        const img = document.createElement('img');
        img.setAttribute('class', 'pointer');
        document.body.appendChild(img);
        img.src = './assets/images/cursor.png';
        return img;
    })(),
    move: function(x, y) {
        this.pointer.style.left = `${x}px`;
        this.pointer.style.top = `${y}px`;
    }
}

function parseCookies(cookies) {
    let result = {}
    const items = cookies.split(';');

    for(const item of items) {
        const [ key, value ] = item.replace(/"/g, '\'').split('='); //replace " with ', to avoid errors
        Object.assign(result, JSON.parse(`{
            "${key}": "${value}"
        }`));
    }

    return result;
}

const loop = () => {
    try {
        if(!ws || ws.readyState === WebSocket.CLOSED) {
            ws = new WebSocket(`ws://${location.hostname}:443?control_ip=${parseCookies(document.cookie)['control_device']}`);
            ws.addEventListener('error', () => void(0));
            ws.addEventListener('close', () => ws = null);
            ws.addEventListener('message', async e => {
                const command = e.data.split('$,$');
                switch(command[0]) {
                    case 'stream':
                        const args = command[1].split('%.%');
                        screen.src = args[4];
                        const x = map(args[2], 0, args[0], 0, screen.width);
                        const y = map(args[3], 0, args[1], 0, screen.height)
                        pointer.move(x, y);
                        break;
                }
            });
        }
    } catch(e) {
        ws = null;
    }
}
loop();
setInterval(loop, 1000);

window.addEventListener('mousedown', e => {
    e.preventDefault();
    if(ws && ws.readyState === WebSocket.OPEN)
        ws.send(`mouse$,$${window.innerWidth}&${window.innerHeight}&${e.screenX}&${e.screenY}&left&down`); //&left&single
});

window.addEventListener('mouseup', e => {
    e.preventDefault();
    if(ws && ws.readyState === WebSocket.OPEN)
        ws.send(`mouse$,$${window.innerWidth}&${window.innerHeight}&${e.screenX}&${e.screenY}&left&up`); //&left&single
});

window.addEventListener('contextmenu', e => {
    e.preventDefault();
    if(ws && ws.readyState === WebSocket.OPEN)
        ws.send(`mouse$,$${window.innerWidth}&${window.innerHeight}&${e.screenX}&${e.screenY}&right`); //&left&single
});

window.addEventListener('wheel', e => {
    e.preventDefault();
    ws.send(`mouse$,$${window.innerWidth}&${window.innerHeight}&${e.screenX}&${e.screenY}&scroll&${e.deltaY}`); //&left&single
});

window.addEventListener('mousemove', e => {
    e.preventDefault();
    if(ws && ws.readyState === WebSocket.OPEN)
        ws.send(`mouse$,$${window.innerWidth}&${window.innerHeight}&${e.screenX}&${e.screenY}`);
});

let triggered = false;

window.addEventListener('keydown', e => {
    e.preventDefault();
    if(triggered)
        return;
    triggered = true;
    console.log('down', e);
    if(ws && ws.readyState === WebSocket.OPEN)
        ws.send(`key$,$down&${e.key}`);
});

window.addEventListener('keyup', e => {
    e.preventDefault();
    if(!triggered)
        return;
    triggered = false;
    console.log('up', e);
    if(ws && ws.readyState === WebSocket.OPEN)
        ws.send(`key$,$up&${e.key}`);
});

function map(value, in_min, in_max, out_min, out_max) {
    return (value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}