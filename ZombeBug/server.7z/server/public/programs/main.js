function run(program) {
    const req = new XMLHttpRequest();
    req.open('GET', `/run?program=${program}`, true);
    req.send();
}