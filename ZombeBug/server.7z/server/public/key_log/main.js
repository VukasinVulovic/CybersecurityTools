parseLog();

async function parseLog() {
    const lines = (await getUrl('/keystrokes')).split('\n');
    for(const line of lines)
        createItem(line);
}

async function createItem(item) {
    const table = document.querySelector('.results');
    const tr = document.createElement('tr');
    const key = document.createElement('td');
    key.innerText = item;
    tr.appendChild(key);
    table.appendChild(tr);
}

async function getUrl(url) {
    return new Promise((resolve, reject) => {
        const req = new XMLHttpRequest();
        req.onreadystatechange = e => {
            if(req.readyState === 4 && req.status === 200)
                resolve(req.responseText);
        }
        req.open('GET', url, true);
        req.send();
    });
}