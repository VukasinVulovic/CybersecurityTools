window.addEventListener('load', init);

async function init() {
    if(!window.location.search)
        location.href = '/explorer?explore=c://Users';
    
    const params = new URLSearchParams(window.location.search);
    const path = params.get('explore');

    const path_input = document.querySelector('.dir');
    path_input.value = path;
    path_input.addEventListener('change', () => {
        location.href = `/explorer?explore=${path_input.value}`;
    });

    const res = await getUrl(`${location.origin}/list?path=${encodeURIComponent(path)}`);
    const list = JSON.parse(res);
    for(const name in list)
        createItem(list[name], name);

    const wrapper = document.querySelector('.wrapper');
    wrapper.addEventListener('contextmenu', e => {
        if(e.target === wrapper || e.target === document.querySelector('.wrapper .file-menager'))
            contextMenu(e, false);
    });

    window.addEventListener('drop', e => {
        e.preventDefault();
        const formData = new FormData();
        formData.append('file', e.dataTransfer.files[0]);
        fetch(`/upload?path=${encodeURIComponent(path)}`, {
            method: 'POST',
            body: formData
        }).then(location.reload, console.log);
    });

    window.addEventListener('dragover', e => {
        e.preventDefault();
    });

    document.querySelector('.back').addEventListener('click', backButton);

}

function backButton() {
    const params = new URLSearchParams(window.location.search);
    const path = params.get('explore');
    if(path.lastIndexOf('/') > 3)
        location.href = `/explorer?explore=${path.slice(0, path.lastIndexOf('/'))}`;
}

function createItem(item_type, item_name) {
    const wrapper = document.querySelector('.wrapper .file-menager');
    const container = document.createElement('div');
    const a = document.createElement('a');
    const icon = document.createElement('img');
    const name = document.createElement('span');

    container.setAttribute('class', 'container');
    icon.setAttribute('class', 'icon');
    name.setAttribute('class', 'name');

    a.title = item_name;
    a.addEventListener('contextmenu', e => contextMenu(e, item_name));

    if(item_type === 'file')
        a.onclick = e => e.preventDefault();
    else {
        a.onclick = () => {
            const params = new URLSearchParams(window.location.search);
            const path = params.get('explore');
            location.href = `/explorer?explore=${path}/${item_name}`;
        }
    }

    icon.alt = item_type;
    icon.src = `/explorer/assets/images/${item_type}.png`;
    name.title = item_name;
    name.innerText = item_name.length <= 24 ? item_name : `${item_name.slice(0, 24)}...`;

    a.appendChild(icon);
    a.appendChild(name);
    container.appendChild(a);
    wrapper.appendChild(container);
}


function contextMenu(e, item_name) {
    e.preventDefault();

    const wrapper = document.querySelector('.wrapper .file-menager');
    let menu = wrapper.querySelector('.context-menu');

    if(menu)
        wrapper.removeChild(menu);

    const params = new URLSearchParams(window.location.search);
    const path = `${params.get('explore')}/${item_name || ''}`;
    let options = {}
        
    if(item_name) { //if clicked on item
        options = {
            'open': `javascript:getUrl('/cmd?path=${path.slice(0, path.lastIndexOf('/'))}&command=start%20${path}')`,
            'delete': `/delete?path=${path}`,
            'save': `/requestfile?path=${path}`
        }
        
    } else {
        options = {
            'upload': `javascript:uploadFile()`
        }
    }

    menu = document.createElement('div');
    menu.setAttribute('class', 'context-menu');

    const remove = () => {
        if(!wrapper.querySelector('.context-menu'))
            return;
        wrapper.removeChild(menu);
        wrapper.removeEventListener('click', remove);
    }
    wrapper.addEventListener('click', remove);

    menu.style.left = `${e.pageX}px`;
    menu.style.top = `${e.pageY}px`;

    for(const opt in options) {
        const i = Object.keys(options).indexOf(opt);
        const a = document.createElement('a');
        a.setAttribute('class', 'item');
        a.href = options[opt];
        a.innerText = opt;

        if(i !== 0 && i < Object.keys(options).length)
            menu.appendChild(document.createElement('hr'));

        menu.appendChild(a);
    }

    wrapper.appendChild(menu);
}

function uploadFile() {
    const form = document.createElement('form');
    const input = document.createElement('input');
    const submit = document.createElement('button');
    input.type = 'file';
    input.name = 'file';
    input.multiple = false;
    submit.type = 'submit';
    form.style.display = 'none';
    form.target = 'print';
    form.method = 'post';
    form.enctype = 'multipart/form-data';
    const params = new URLSearchParams(window.location.search);
    const path = `${params.get('explore')}/`;
    form.action = `/upload?path=${encodeURIComponent(path)}`;

    form.onsubmit = () => {
        const iframe = document.createElement('iframe');
        iframe.name = 'print';
        iframe.setAttribute('style', 'display: none;');
        document.body.appendChild(iframe);
    }

    form.appendChild(input);
    form.appendChild(submit);
    document.body.appendChild(form);

    input.click();

    input.onchange = () => {
        submit.click();
        document.body.removeChild(form);
    }
}

async function getUrl(url) {
    return new Promise((resolve, reject) => {
        const req = new XMLHttpRequest();
        req.onreadystatechange = e => {
            if(req.readyState === 4 && req.status === 200)
                resolve(req.responseText);
        }
        req.open('GET', url, true);
        req.send();
    });
}