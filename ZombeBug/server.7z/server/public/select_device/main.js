async function main() {
    const devices = JSON.parse(await getUrl('/list_devices'));
    for(const device of devices)
        await createDevice(device);
}
main();

async function createDevice(device) {
    const info = await dnsLookup(device);
    
    const wrapper = document.querySelector('.wrapper');
    const container = document.createElement('div');
    const image = document.createElement('img');
    const title = document.createElement('span');
    const location = document.createElement('span');
    const isp = document.createElement('span');

    container.setAttribute('class', 'device');
    image.setAttribute('class', 'image');
    title.setAttribute('class', 'title');
    location.setAttribute('class', 'location');
    isp.setAttribute('class', 'isp');

    image.src = './assets/images/device_icon.png';
    title.innerText = device;
    location.innerText = `${info['country']}, ${info['city']}`;
    isp.innerText = info['isp'];

    container.addEventListener('click', e => {
        document.cookie = `control_device=${device};path=/`;
        setTimeout(() => {
            window.location.replace('/');
        }, 200);
    });

    if(device === parseCookies(document.cookie)['control_device'])
        container.style.opacity = 1; //higher opacity for the selected device

    container.appendChild(image);
    container.appendChild(title);
    container.appendChild(location);
    container.appendChild(isp);
    wrapper.appendChild(container);
    return 0;
}

async function dnsLookup(device) {
    const [public_ip, private_ip] = device.split('>')
    const info = JSON.parse(await getUrl(`/iplookup?ip=${public_ip}`));
    return info;
}

async function getUrl(url) {
    return new Promise((resolve, reject) => {
        const req = new XMLHttpRequest();
        req.onreadystatechange = e => {
            if(req.readyState === 4 && req.status === 200)
                resolve(req.responseText);
        }
        req.open('GET', url, true);
        req.send();
    });
}

function parseCookies(cookies) {
    let result = {}
    const items = cookies.split(';');

    for(const item of items) {
        const [ key, value ] = item.replace(/"/g, '\'').split('='); //replace " with ', to avoid errors
        Object.assign(result, JSON.parse(`{
            "${key}": "${value}"
        }`));
    }

    return result;
}