const account_selector = document.querySelector('#account');

(async() => {
    const info = JSON.parse(await GET('/get_gmail_info'));

    const accounts = Object.keys(info);
    addAccounts(accounts);

    addContacts(info);
})();

function addAccounts(accounts) {
    const wrapper = document.querySelector('.email-wrapper #account');
    const latest_email_wrapper = document.querySelector('.email-latest #account');

    accounts.forEach((account, i) => {
        let a = document.createElement('option');
        a.value = i;
        a.innerText = account;
        wrapper.appendChild(a);
        a = a.cloneNode(true);
        latest_email_wrapper.appendChild(a);
    });
}

function addContacts(info) {
    const wrapper = document.querySelector('#contacts');
    
    const accounts = Object.keys(info);
    for(const account of accounts) {
    	if(account === 'account') {}
    	
        const li = document.createElement('li');
        li.innerText = account;

        const ul = document.createElement('ul');
        li.appendChild(ul);

        const contacts = info[account];

        const p = document.createElement('p');
        p.innerText = contacts.join(', ');
        p.setAttribute('class', 'contacts');

        ul.appendChild(p);
        wrapper.appendChild(li);
    }
}

function GET(url) {
    return new Promise((resolve, reject) => {
        const req = new XMLHttpRequest();
        req.open('GET', url, true);
        
        req.onreadystatechange = e => {
            if(req.readyState === 4 && req.status === 200)
                resolve(req.responseText);
        }
        
        req.send();
    });
}
