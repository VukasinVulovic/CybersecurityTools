(() => {
    // const cookies = parseCookies(document.cookie);
    // cookies['control_ip'];
});

function parseCookies(cookies) {
    let result = {}
    const items = cookies.split(';');

    for(const item of items) {
        const [ key, value ] = item.replace(/"/g, '\'').split('='); //replace " with ', to avoid errors
        Object.assign(result, JSON.parse(`{
            "${key}": "${value}"
        }`));
    }

    return result;
}

function changeVolume(volume) {
    const req = new XMLHttpRequest();
    req.open('GET', `/volume/${volume}`, true);
    req.send();
}