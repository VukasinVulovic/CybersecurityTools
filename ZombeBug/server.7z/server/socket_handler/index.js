const WebSocket = require('ws');
const url = require('url');
let Sockets = {}
let Selected_Socket = null;

module.exports = {
    init: (Server, connection_cb) => {   
        return new Promise((resolve, reject) => {
            try {
                const Ws = new WebSocket.Server({
                    server: Server
                });
                
                Ws.on('connection', (socket, req) => {
                    const ip = url.parse(req.url, true).query['ip'];
                    Sockets[ip] = socket;
                    socket.ip = ip;
                    socket.on('close', () => delete Sockets[socket]);
                    connection_cb(ip, socket);
                });
                
                resolve(Ws);
            } catch(e) {
                reject(e);
            }
        });
    },
    list: () => {
        return Sockets; 
    },
    selected: () => {
        return Selected_Socket;
    },
    select: ip => {
        for(const s in Sockets) {
            if(Sockets[s].ip === ip)
                return Selected_Socket = Sockets[ip];
        }
        return null;
    },
    ready: () => {
        return !Selected_Socket === false; //return true or false
    },
    ping: async function(ip) {
        return new Promise(async(resolve, reject) => {
            try {
                const TIMEOUT = 2000; //ms
                let prev = Selected_Socket.ip; //temp

                if(!this.select(ip)) //check if socket can be selected(exists)
                    return resolve(false);    

                const fail = setTimeout(() => resolve(false), TIMEOUT);//request timed out
                const res = await this.send(`ping$,$${new Date().getTime()}`);
                this.select(prev);
                clearTimeout(fail);
                resolve(Number(res));
            } catch(e) {
                reject(e);
            }
        });
    },
    send: command => {
        return new Promise((resolve, reject) => {
            try {
                Selected_Socket.send(command);
                const cb = message => resolve(message);
                Selected_Socket.addEventListener('message', message => {
                    cb(message['data']);
                    Selected_Socket.removeEventListener('message', cb);
                });
            } catch(e) {
                Selected_Socket = null;
                reject(e);
            }
        });
    }
}