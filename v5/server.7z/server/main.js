const URL = require('url');
const { Server } = require('./index');
const http = require('http');
const express = require('express');
const WebSocket = require('ws');

(async() => {
    console.clear();
    const server = new Server({
        port: 3000,
        uploadPath: '/upload',
        downloadPath: '/download',
    }, () => console.log('Server is running!'));

    server.onError(console.error);
    server.onConnection(async conn => {
        console.log(`New connection: "${conn['id']}"`);
    });

    const router = express();
    router.get('/connections', (req, res) => res.json(server.sockets)); //show connected clients
    router.use('/', express.static('./public'));

    const main_server = http.createServer(router);
    const ws = new WebSocket.Server({
        server: main_server
    });

    ws.on('connection', (conn, req) => {
        const id = decodeURIComponent(URL.parse(req.url, true).query['id']); //id of the socket

        const error = err => conn.send(JSON.stringify({ 'f': 'error', 'data': err }));
        const reply = (f, data) => conn.send(JSON.stringify({ f, data }));

        if(!server.sockets[id])
            return error('Socket with id: "' + id + '", not connected;');

        conn.on('message', msg => {
            if(!server.sockets[id])
                return error('Socket with id: "' + id + '", not connected;');

            const { e, f, data } = JSON.parse(msg);

            switch(e) {
                case 'exec':
                    server.onError(error); //FIX LATER
                    server.execFunction(id, f, data, d => reply(f, d)); //exec function (sokcet id, function, data, callback)
                    server.sockets[id].send(JSON.stringify({ f, data }));
                    break;

                case 'spawn':;
                    server.onError(error); //FIX LATER
                    server.spawnFunction(id, f, data, (d, reply_, close) => reply(f, d)); //exec function (sokcet id, function, data, callback)
                    server.sockets[id].send(JSON.stringify({ f, data }));
                    break;

                    default:
                        error('unknown event type;');
            }
        }); 
    });

    main_server.listen(80, () => console.log('Listenig at port 80.'));

    console.clear();
})();

// app.get('/function', async(req, res) => {
//     const socket_id = Object.keys(server.sockets)[0];

//     if(!socket_id)
//         return res.end('No socket connected.');

//     server.execFunction(socket_id, req.query['f'], decodeURIComponent(req.query['data']), data => {
//         if(typeof data === 'object')
//             res.json(data);
//         else
//             res.write((data || '').toString());
//         res.end();
//     });
// });

// app.get('/', async(req, res) => {
//     const socket_id = Object.keys(server.sockets)[0];

//     if(!socket_id)
//         return res.end('No socket connected.');



//     server.spawnFunction(socket_id, req.query['f'], decodeURIComponent(req.query['data']), (msg, reply, close) => {
//         msg = JSON.parse(msg);

//         if(msg['e'] === 'data') 
//             res.write(new Buffer.from(msg['data']));
//         else if(msg['e'] === 'close')
//             res.end();
//     });
// });

// app.get('/spawn_function', async(req, res) => {
//     const socket_id = Object.keys(server.sockets)[0];

//     if(!socket_id)
//         return res.end('No socket connected.');

//     server.spawnFunction(socket_id, req.query['f'], (req.query['data'] || ''), (msg, reply, close) => {
//         msg = JSON.parse(msg);

//         console.log(msg['e']);

//         if(msg['e'] === 'data') 
//             res.write(new Buffer.from(msg['data']));
//         else if(msg['e'] === 'close')
//             res.end();
//     });
// });
