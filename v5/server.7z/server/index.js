const path = require('path');
const URL = require('url');
const fs = require('fs');
const http = require('http');
const WebSocket = require('ws');


module.exports = {
    Server: class {
        constructor(opts, cb=() => {}) {
            this.opts = Object.assign({ 
                generate_id: true,
                port: 80, 
                tempDir: (() => {
                    const p = `${__dirname}/%temp%`;
                    if(!fs.existsSync(p)) 
                        fs.mkdirSync(p);
                    
                    return p;
                })(), 
                uploadPath: false, 
                downloadPath: false 
            }, opts);
            this.listenCb = cb;
            this.errCb = console.error;

            this.fileCb = async() => { 
                return {                   
                    accept: true,
                    empty_temp: true, 
                    path: this.opts['tempDir'],
                    cb: p => console.log(`Upload ${p}% done.`) 
                }
            }

            this.onFileReqestCb = async() => { 
                return {
                    accept: true,
                    empty_temp: true,
                    path: this.opts['tempDir'],
                    cb: p => console.log(`Upload ${p}% done.`)
                }
            }
            this.cb = () => {} //this.errCb(new Error('No functions set.'))
            this.connectionCb = () => {}
            this.server = null;
            this.ws = null;
            this.sockets = {}
            this.__listen();
        }

        __listen() {
            const server = http.createServer(async(req, res) => {
                const url_path = req['url'].endsWith('/') ? req['url'].slice(0, -1) : req['url'];
                
                if(this.opts['uploadPath'] && (url_path === this.opts['uploadPath'])) {
                    if(!(req['method'].toLowerCase() === 'post')) {
                        res.statusCode = 405;
                        res.statusMessage = 'Method not POST.';
                        return res.end('Method not POST.');
                    }
                    
                    const name = req['headers']['name'];
                    const size = req['headers']['size'];

                    const ret = await this.fileCb({
                        name: name,
                        size: size,
                        date: new Date()
                    });


                    if(!ret['accept']) {
                        res.statusCode = 403;
                        res.statusMessage = 'The server denied the upload of this file.';
                        return res.end('The server denied the upload of this file.');
                    }

                    const s = fs.createWriteStream(path.join(ret['path'] || __dirname, name));
                    req.pipe(s);

                    let perc_prev = 0;
                    let bytes_done = 0;

                    req.on('data', chunk => {
                        bytes_done += chunk.length;
                        const perc = ((100 * bytes_done) / size).toFixed(0);

                        if(perc_prev === perc)
                            return;
                        
                        (ret['cb'] || (() => {}))(perc);
                        perc_prev = perc;
                    });

                    req.on('error', this.errCb);
                    req.on('end', () => {
                        res.statusCode = 200;
                        res.statusMessage = 'File uploaded succesfully.';
                        res.end('File uploaded succesfully.');
                    });
                } else if(this.opts['downloadPath'] && (url_path === this.opts['downloadPath'])) {
                    if(!(req['method'].toLowerCase() === 'get')) {
                        res.statusCode = 405;
                        res.statusMessage = 'Only GET method is allowed.';
                        return res.end();
                    }
                    
                    const name = req['headers']['name'];

                    const file_path = path.join(this.opts['tempDir'], name);
                    const size = fs.statSync(file_path)['size'];

                    const ret = await this.onFileReqestCb({
                        name: name,
                        size: size,
                        date: new Date()
                    });

                    if(!ret['accept']) {
                        res.statusCode = 403;
                        res.statusMessage = 'The server denied the download of this file.';
                        return res.end('The server denied the download of this file.');
                    }

                    res.setHeader('size', size);

                    const s = fs.createReadStream(file_path);
                    s.pipe(res);

                    let perc_prev = 0;
                    let bytes_done = 0;
                    const cb = (ret['cb'] || (() => {}));

                    s.on('data', chunk => {
                        bytes_done += chunk.length;
                        const perc = ((100 * bytes_done) / size).toFixed(0);

                        if(perc_prev === perc)
                            return;
                        
                        cb(perc);
                        
                        try {
                            if(perc >= 100 && ret['empty_temp'])
                                fs.rmSync(file_path);
                        } catch(err) {
                            this.errCb(err);
                        }

                        perc_prev = perc;
                    });
                } else {
                    res.statusCode = 404;
                    res.statusMessage = 'Path not found on server.';
                    return res.end('Path not found on server.');
                }
            });

            const ws = new WebSocket.Server({
                server: server
            });
            
            ws
            .on('connection', (socket, req) => {
                socket = Object.assign(socket, URL.parse(req.url, true)['query'], {
                    public_ip: req.headers['x-forwarded-for'] || req.connection.remoteAddress
                });

                const id = this.opts['generate_id'] ? (socket['public_ip'] + '@' + socket['local_ip'] + ':' + socket['name']) : req['headers']['sec-websocket-key'];
                socket['id'] = id;
                this.sockets[id] = socket;
                this.connectionCb(socket);

                socket
                .on('close', () => delete this.sockets[id])
                .on('error', err => this.errCb(err))
                .on('message', data => {
                    try {
                        const message = JSON.parse(data); 
                       
                        if(!message['f'])
                            return this.errCb(new Error('No function provided!'));
                        
                        switch(message['f']) {
                            case 'error':
                                this.errCb(message['data']);
                                break; 

                            default:
                                this.cb(socket, message['f'], message['data'], data => this.send(id, message['f'], message['f'],  data), err => this.send(id, 'error', 'error', err))
                        }
                    } catch(err) {
                        this.errCb(err);
                    }
                });

                this.sockets[id] = socket;
            })
            .on('error', err => this.errCb(err));

            server.listen(this.opts['port'], this.listenCb);
            this.server = server;
        }

        execFunction(socketId, f, data, cb) {
            const f_cb = (() => {
                let id = '';

                while(id.length < 20)
                    id += '1234567890qwertyuiopasdfghjklzxcvbnm'[Math.floor(Math.random() * 36)];
                
                return id;
            })() + '@' + socketId;

            this.send(socketId, f, f_cb, data);
            const socket = this.sockets[socketId];
            
            const mcb = data => {
                const message = JSON.parse(data.data); 
                       
                if(message['f'] === f_cb) {
                    cb(message['data']);
                    socket.removeEventListener('message', mcb);
                }
            }
            
            socket.addEventListener('message', mcb);
        }

        spawnFunction(socketId, f, data, cb) {
            const f_cb = (() => {
                let id = '';

                while(id.length < 20)
                    id += '1234567890qwertyuiopasdfghjklzxcvbnm'[Math.floor(Math.random() * 36)];
                
                return id;
            })() + '@' + socketId;
            
            this.send(socketId, f, f_cb, data);
            const socket = this.sockets[socketId];

            const mcb = data => {
                const message = JSON.parse(data.data); 
                
                if(message['f'] === f_cb) {
                    return cb(message['data'], data => this.send(socketId, f, f_cb, data), () => {
                        this.send(socketId, f, f_cb, 'close');
                        socket.removeEventListener('message', mcb);
                    });
                }
            }
            
            socket.addEventListener('message', mcb);
        }

        send(socketId, f, f_cb, data) {
            this.sockets[socketId]
            .send(new Buffer.from(JSON.stringify({
                f,
                f_cb,
                data
            })));
        }

        getFile(socketId, file_path) {
            this.sockets[socketId]
            .send(new Buffer.from(JSON.stringify({
                f: 'get-file',
                f_cb: 'send-file',
                data: {
                    file: file_path
                }
            })));
        }

        sendFile(socketId, file_path, dest_dir) {
            const file = path.basename(file_path);

            fs.copyFile(file_path, `${this.opts['tempDir']}/${file}`, () => {
                this.send(socketId, 'send-file', 'send-file', {
                    file,
                    dest_dir
                });
            });
        }

        onFunction(cb) {
            this.cb = cb;
        }

        onFile(cb) {
            this.fileCb = cb;
        }

        onFileReqest(cb) {
            this.onFileReqestCb = cb;
        }

        onConnection(cb) {
            this.connectionCb = cb;
        }

        onError(cb) {
            this.errCb = cb;
        }
    }
}