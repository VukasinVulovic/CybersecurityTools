function main() {
}

main();