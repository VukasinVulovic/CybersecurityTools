async function alert(type, text) {
    return new Promise(resolve => {
        const main = document.createElement('div');
        const icon = document.createElement('img');
        const close = document.createElement('span');
        const message = document.createElement('span');
        icon.alt = 'icon';
        close.setAttribute('class', 'close');
        close.innerHTML = '&#8857;';
        message.innerText = text;
        
        let removed = false;

        const remove = v => {
            if(removed)
                return;

            document.body.removeChild(main);
            removed = true;
            resolve(v);
        }
        
        close.addEventListener('click', () => remove(0));
        
        if(type !== 'input')
            setTimeout(() => remove(0), 3000);
    
        switch(type) {
            case 'error':
                main.setAttribute('class', 'alert');
                icon.setAttribute('class', 'icon-error');
                message.setAttribute('class', 'message error');
                main.append(icon, message, close);
                break;
    
            case 'warning':
                main.setAttribute('class', 'alert');
                icon.setAttribute('class', 'icon-warning');
                message.setAttribute('class', 'message warning');
                main.append(icon, message, close);
                break;
    
            case 'info':
                main.setAttribute('class', 'alert');
                icon.setAttribute('class', 'icon-info');
                message.setAttribute('class', 'message info');
                main.append(icon, message, close);
                break;
    
            case 'input':
                main.setAttribute('class', 'input-prompt');
                icon.setAttribute('class', 'icon');
                message.setAttribute('class', 'message input');
                icon.src = '/assets/images/icons/alerts/input.svg';
    
                const inp = document.createElement('input');
                inp.setAttribute('class', 'input');
                inp.type = 'text';
                message.appendChild(inp);
                
                inp.addEventListener('keydown', e => {
                    if(e.key === 'Enter')
                        remove(inp.value);
                });
    
                const arrow = document.createElement('img');
                arrow.alt = 'arrow';
                arrow.setAttribute('class', 'arrow');
                arrow.role = 'button';
                arrow.src = '/assets/images/icons/alerts/arrow_forward.svg';
                arrow.addEventListener('click', () => remove(inp.value));

                main.append(icon, message, arrow);
                break;
            
            default:
                throw new Error('Unknown alert type.');
        }
    
        document.body.appendChild(main);
    });
}