function writeLine(text, type) {
    const el = document.querySelector('.main > div.terminal > div.output');

    switch(type) {
        case 'error':
            el.innerHTML += '<span class="error">' + text + '</span><br>';
            break;
        
        case 'success':
            el.innerHTML += '<span class="success">' + text.replace('<', '&lt;').replace('>', '&gt;') + '</span><br>';
            break;
        
        default:
            el.innerHTML += text + '<br>';
    }

    el.scrollTop = el.scrollHeight;
    return text;
}

function inputHandler() {
    const inp = document.querySelector('.main > div.terminal > div.input > input[type="text"]');
    const path_el = document.querySelector('.main > div.terminal > div.input > .path');
    const history = [];
    let i = 0;

    const h = spawnFunction('system.Exec', d => {
        d = d.replace(/\r\n/g, '');

        if(d.length < 0)
            return;

        writeLine(d, 'success');
        // path_el.innerHTML = path + '<span style="color: var(--terminal-text-regular);">$</span>';
    }, () => writeLine('Terminal function closed.', 'error'))

    inp.addEventListener('keydown', e => {
        if(e.key === 'Enter') {
            if(inp.value.length < 1)
                return;

            writeLine('>>> ' + inp.value, 'text');
            
            // const v = inp.value.match(/(?:[^\s"]+|"[^"]*")+/g);
            h.reply(inp.value);
                
            if(history[history.length-1] !== inp.value) {
                history.push(inp.value);
                i = history.length;
            }

            inp.value = '';
        } else if(e.key === 'ArrowDown') {
            e.preventDefault(); 
            if(i+1 < history.length)
                i++;
            
            inp.value = history[i];
        } else if(e.key === 'ArrowUp') {
            e.preventDefault(); 
            if(i > 0)
                i--;

            inp.value = history[i];

        }
    });
}

inputHandler();