let WS = new WebSocket(location.href.replace('http', 'ws') + '?id=::ffff:127.0.0.1@192.168.1.26:TheUnknown');

WS.onerror = err => alert('error', err);
WS.onclose = () => alert('info', 'Connection to server closed;');

function execFunction(f, data, cb) {
    const mcb = e => {
        const { f:func, data:d } = JSON.parse(e.data);

        if(func === 'error')
            writeLine(JSON.stringify(d), 'error');
        else if(func === f)
            cb(d);
        else 
            alert('warning', 'Unknown function "' + func + '";');

        WS.removeEventListener('message', mcb);
    }

    WS.addEventListener('message', mcb);
    WS.send(JSON.stringify({ e: 'exec', f, data }));
}

function spawnFunction(f, ondata, onend) {
    const mcb = e => {
        const { f:f_, data:data_ } = JSON.parse(e.data);
        
        if(f_ === 'error') {
            if(data_.length > 0)
                writeLine(JSON.stringify(data_), 'error');
        } else if(f_ === f) {
            const { e:e_, data:d_ } = JSON.parse(data_);

            if(e_ === 'data')
                ondata(d_);
            else if(e_ === 'close')
                onend();
        }

        // if(func === 'error')
            // console.log(d);
            // writeLine(JSON.stringify(d), 'error');
        // else
        // if(func === f) {
        //     console.log(p);

        //     if(e === 'data')
        //         console.log(data['data'].toString());
        //     else if(ev === 'close')
        //         onend(f);
        // } 
        // else 
        //     alert('warning', 'Unknown function "' + func + '";');
        // WS.removeEventListener('message', mcb);
    }

    WS.addEventListener('message', mcb);
    
    return {
        reply: data => WS.send(JSON.stringify({ e: 'spawn', f, data }))
    }
}