const os = require('os');
const fs = require('fs');
const { spawn } = require('child_process');
const Path = require('path');

__dirname = process.cwd() + '\\exec_7z';

module.exports = exec7Z;

function tempDir() {
    let temp = os.tmpdir() + '\\';
    
    let i = 0;
    while(i++ < 20)
        temp += '1234567890qwertyuiopasdfghjklzxcvbnm'[Math.floor(Math.random() * 36)];

    if(!fs.existsSync(temp))
        fs.mkdirSync(temp);
    
    return temp; 
}

async function unzip7Z(exe_path, inp) {
    return new Promise((resolve, reject) => {                
        const temp = tempDir();
        
        spawn(exe_path, [ 'x', inp, '-aoa', '-o' + temp, '-y' ])
        .on('exit', () => resolve(temp))
        .on('error', err => reject(err));
    });
}

function getZipPath(path) {
    let zip = '';
    let file = ''

    let flag = false;

    for(const p of Path.normalize(path).split('\\')) {        
        if(flag)
            file += p + '\\';
        else
            zip += p + '\\';
            
        if(p.includes('.7z'))
            flag = true;
    }

    return {
        zip_path: zip.substring(0, zip.length-1),
        file: file.substring(0, file.length-1)
    }
}

async function exec7Z(exe_path, args, errCb, dataCb) {
    return new Promise(async(resolve, reject) => {
        let data = '', err = '';
        
        const { zip_path, file } = getZipPath(exe_path);
        const temp = await unzip7Z(__dirname + '\\bin\\7zip.exe', zip_path);
        
        const path = temp + '\\' + file;
        const p = Path.parse(path)

        const s = spawn(p.base, {
            cwd: p.dir
        }, args.match(/(?:[^\s"]+|"[^"]*")+/g));

        s.stderr
        .on('data', c => err += c.toString())
        .on('end', () => (errCb ? errCb : reject)(err));

        s.stdout
        .on('data', c => {
            c = c.toString();
            data += c;
            
            if(dataCb)
                dataCb(c)
        })
        .on('end', () => resolve(data));
    });
}