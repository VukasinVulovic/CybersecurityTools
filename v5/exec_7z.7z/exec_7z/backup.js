const os = require('os');
const fs = require('fs');
const { spawn } = require('child_process');
const Path = require('path');

(async() => {
    const s = spawn('main.exe', [], {
        cwd: __dirname + '\\q37rwx9plxzcup36dkay',
    });

    let d = '';
    let e = '';

    s.stdout
    .on('data', c => d += c.toString())
    .on('end', () => console.log(d));

    s.stderr
    .on('data', c => e += c.toString())
    .on('end', () => console.log(e));

})().catch(console.error);