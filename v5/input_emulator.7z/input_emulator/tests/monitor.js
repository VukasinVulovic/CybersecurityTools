const InputEmulator = require('../index');

(async() => {
    const em = new InputEmulator();
    await em.sleep(1000);

    const info = await em.monitor.getInfo();
    console.log(info);

    em.stop();
})().catch(console.error);