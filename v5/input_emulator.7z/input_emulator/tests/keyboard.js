const https = require('https');
const InputEmulator = require('../index');
const url = 'https://raw.githubusercontent.com/brunoklein99/deep-learning-notes/master/shakespeare.txt';

(async() => {
    const em = new InputEmulator();

    em.key_timeout = 0;

    await em.sleep(1000);
    em.keyboard.keyPress('ctrl+n');

    let text = '';

    https
    .get(url)
    .on('error', console.error)
    .on('response', res => {
        if(res.statusCode !== 200)
            return console.log(res.statusMessage);
            
        res
        .on('error', console.error)
        .on('data', chunk => {
            text += chunk.toString();
        })
        .on('end', async() => {
            await em.keyboard.typeString(text);
            em.stop();
            console.log('Fin.');
        });
    });
})().catch(console.error);