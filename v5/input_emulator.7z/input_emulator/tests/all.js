const InputEmulator = require('../index');

(async() => {
    const em = new InputEmulator();
    await em.sleep(1000);

    const monitor = await em.monitor.getInfo(); //get monitor info
    const mouse_pos = await em.mouse.getPosition();

    em.keyboard.keyPress('windows');
    await em.sleep(100);

    let y = mouse_pos.y;

    await new Promise(resolve => {
        const loop = setInterval(() => {
            if(y++ >= monitor.height) {
                resolve();
                return clearInterval(loop);
            }
    
            em.mouse.moveTo(1, y);
        }, 4);
    });

    await em.sleep(100);
    em.mouse.leftClickPress();
    await em.sleep(100);
    em.stop();
})().catch(console.error);