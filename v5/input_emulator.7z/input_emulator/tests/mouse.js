const InputEmulator = require('../index');

(async() => {
    const em = new InputEmulator();
    await em.sleep(1000);

    em.mouse.moveTo(100, 100);
    await em.sleep(100);
    em.mouse.rightClickPress();
    await em.sleep(100);
    await em.stop();
})().catch(console.error);