const { spawn, exec } = require('child_process');
const keycode = require('keycode');

class InputEmulator {
    constructor() {
        this.process = {};
        this.exe = {
            // sim: __dirname + '\\bin\\sim.exe',
            keyboard: __dirname + '\\bin\\keyboard.exe',
            mouse: __dirname + '\\bin\\mouse.exe',
            monitor: __dirname + '\\bin\\monitor.exe'
        }
        this.key_timeout = 2; //ms
        this.__keys_down = {}
        this.__buttons_down = {}
        this.__monitor_info = {}
        this.sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
        this.__spawnProcess();
    }

    __getKeyCode(s) {
        let code = 
        ({
            '\n': 13,
            '\t': 9,
            '!': 49,
            '@': 50,
            '#': 51,
            '$': 52,
            '%': 53,
            '^': 54,
            '&': 55,
            '*': 56,
            '(': 57,
            ')': 48,
            '~': 192,
            '{': 219,
            '}': 221,
            ':': 186,
            '"': 222,
            '<': 188,
            '>': 190,
            '?': 191,
            '|': 220,
            '/': 111,
            '_': 189
        })[s]; 

        return (code === undefined) ? keycode(s.toString()) : code;
    }

    __spawnProcess() {
        const kp = spawn(this.exe.keyboard, [], {
            shell: true
        });

        kp.on('error', e => console.log(e.toString()));
        kp.stdout.pipe(process.stdout);
        kp.stderr.pipe(process.stderr);

        const mp = spawn(this.exe.mouse, [], {
            shell: true
        });

        mp.on('error', e => console.log(e.toString()));
        mp.stdout.pipe(process.stdout);
        mp.stderr.pipe(process.stderr);

        this.process = {
            keyboard: kp,
            mouse: mp
        }
    }

    keyboard = {
        keyDown: key => {
            const code = (typeof key === 'number') ? key : keycode(key);
            this.__keys_down[code] = true;
            this.process.keyboard.stdin.write(code + ' 1 0\n');
        },
        keyUp: key => {
            const code = (typeof key === 'number') ? key : keycode(key);
            delete this.__keys_down[code];
            this.process.keyboard.stdin.write(code + ' 2 0\n');
        },
        // keyPress: (key, modifiers={ ctrl: false, shift: false, alt: false, windows: false }) => {
        //     modifiers = Object.assign({ ctrl: false, shift: false, alt: false, windows: false }, modifiers);
    
        //     for(const mod in modifiers) {
        //         if(!modifiers[mod])
        //             continue;
    
        //         this.keyboard.keyDown(mod);
        //     }
    
        //     const code = (typeof key === 'number') ? key : keycode(key);
        //     this.process.keyboard.stdin.write(code + ' 3 ' + this.key_timeout + '\n');
    
        //     for(const mod in modifiers) {
        //         if(!modifiers[mod])
        //             continue;
    
        //         this.keyboard.keyUp(mod);
        //     }
        // },
        keyPress: combination => {  
            if(combination === '+')
                return this.keyboard.keyPress('shift+=');

                const keys = combination.split('+');
            const key = keys.pop();

            for(const k of keys)
                this.keyboard.keyDown(this.__getKeyCode(k));
    
            const code = (typeof key === 'number') ? key : this.__getKeyCode(key);
            this.process.keyboard.stdin.write(code + ' 3 ' + this.key_timeout + '\n');
    
            for(const k of keys)
                this.keyboard.keyUp(this.__getKeyCode(k));
        },
        typeString: async str => {
            for(const s of str.split('')) {   
                const code = (((s === s.toUpperCase()) || (/[*!@#$%^&()_{}:"\\|<>?~]/.test(s))) && !(/[`\-=+\[\];',.\/]/.test(s)) ? 'shift+' : '') + s;
                this.keyboard.keyPress(code);
                await this.sleep(this.key_timeout);
            }
        },
        resetKeys() {
            for(const key in this.__keys_down)
                this.keyboard.keyUp(key);
        }
    }

    mouse = {
        leftDownClick: () => {
            this.process.mouse.stdin.write('1 0 -1 -1\n');
            __buttons_down['0'] = true;
        },
        leftUpClick: () => {
            this.process.mouse.stdin.write('2 0 -1 -1\n');
            delete __buttons_down['0'];
        },
        leftClickPress: () => {
            this.process.mouse.stdin.write('3 0 -1 -1\n');
        },
        rightDownClick: () => {
            this.process.mouse.stdin.write('4 0 -1 -1\n');
            __buttons_down['1'] = true;
        },
        rightUpClick: () => {
            this.process.mouse.stdin.write('5 0 -1 -1\n');
            delete __buttons_down['1'];
        },
        rightClickPress: () => {
            this.process.mouse.stdin.write('6 0 -1 -1\n');
        },
        moveTo: (x, y) => {
            this.process.mouse.stdin.write('0 0 ' + x + ' ' + y + '\n');
        },
        getPosition: async() => {
            const { cursor_x, cursor_y } = await this.monitor.getInfo(true);
            return { 
                x: cursor_x, 
                y: cursor_y 
            }
        }
    }

    monitor = {
        getInfo: async (current=false) => {
            return new Promise(resolve => {
                if(Object.keys(this.__monitor_info).length > 0 && !current)
                    return resolve(this.__monitor_info);

                exec(this.exe.monitor, (err, stdout, stderr) => {
                    if(err)
                        throw err;
                    
                    for(const part of stdout.split(',')) {
                        const p = part.split('=');
                        this.__monitor_info[p[0]] = parseInt(p[1]) || p[1];     
                    }

                    resolve(this.__monitor_info);
                });
            });
        }
    }

    async stop() {
        for(const key in this.__keys_down)
            this.keyboard.keyUp(key);

        for(const key in this.__buttons_down) {
            if(key === 0)
                this.mouse.leftUpClick();
            else
                this.mouse.rightUpClick();
        }

        this.process.keyboard.stdin.write('-1 0 0\n');
        this.process.mouse.stdin.write('-1 0 0 0\n');
        this.process.keyboard.kill();
        this.process.mouse.kill();
    }
}

module.exports = InputEmulator;

// keyboard key (13) OR -1 to exit
// keyboard mode (0=NoKey, 1=keyDown, 2=keyUp, 3=keyPress)
// keyboard time (10ms)

// mouse button (0=no click, 1=left click down, 2=left click up, 3=left click press, 4=right click down, 5=right click up, 6=right click press)
// mouse click time (10ms)
// mouse position x (-1=noChnage, 0px)
// mouse position y (-1=noChnage, 0px)