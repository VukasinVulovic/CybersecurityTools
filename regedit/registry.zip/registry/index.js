const { exec } = require('child_process');

async function execReg(args) {
    return new Promise((resolve, reject) => {
        exec('reg ' + args, {}, (err, stdout, stderr) => {
            if(stderr || err)
                return reject(stderr || err);

            if(stdout.includes('The operation completed successfully.'))
                resolve(0);
            else 
                reject('An error occured.');
        });
    });
}

module.exports = {
    setKeyValue: async(key, name, type, value) => 
        execReg('add ' + key + ' /f /v ' + name + ' /t ' + type + ' /d "' + value.replace('"', '') + '"'),
    deleteValue: async (key, name) => execReg('delete ' + key + ' /v ' + name + ' /f'),
    deleteKey: async key => execReg('delete ' + key + ' /f'),
    createKey: async key => execReg('add ' + key + ' /f'),
    listRegistry: async key => {
        return new Promise((resolve, reject) => {
            exec('reg query ' + key, {}, (err, stdout, stderr) => {
                if(stderr || err)
                    return reject(stderr || err);
    
                const lines = stdout.replace(/\r/g, '').split('\n');
                const reg = {}
                let flag = '';
    
                for(const line of lines) {
                    if(line.length < 0)
                        continue;
    
                    if(!line.includes(' ')) {
                        if(line.length < 1)
                            continue;
    
                        reg[line] = [];
                        flag = line;
                        continue;
                    }
    
                    if(flag !== '') {
                        const [ name, type, value ] = line.trim().split('    ');
                        reg[flag].push({ name, type, value });
                    }
                }
    
                resolve(reg);
            });
        });
    }
}