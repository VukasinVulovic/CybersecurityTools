#include <iostream>
#include "windows.devices.geolocation.h"

int main() {
		
	return 0;
}
