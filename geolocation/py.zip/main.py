import winrt.windows.devices.geolocation as wdg, asyncio

async def main():
    locator = wdg.Geolocator()
    pos = await locator.get_geoposition_async()
    print([pos.coordinate.latitude, pos.coordinate.longitude])

asyncio.run(main())